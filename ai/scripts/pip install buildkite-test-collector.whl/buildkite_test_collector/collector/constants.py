# constants.py

"""This module defines collector-level constants."""

COLLECTOR_NAME='buildkite-test-collector'
VERSION='0.1.9'
